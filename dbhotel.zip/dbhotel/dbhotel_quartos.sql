-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: dbhotel
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quartos`
--

DROP TABLE IF EXISTS `quartos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `quartos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(200) NOT NULL,
  `numpessoas` int(11) NOT NULL,
  `tipoquarto` varchar(20) NOT NULL,
  `valorTotal` double NOT NULL,
  `idcontrato` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idcontrato` (`idcontrato`),
  CONSTRAINT `quartos_ibfk_1` FOREIGN KEY (`idcontrato`) REFERENCES `contratos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quartos`
--

LOCK TABLES `quartos` WRITE;
/*!40000 ALTER TABLE `quartos` DISABLE KEYS */;
INSERT INTO `quartos` VALUES (1,'Quarto Presidencial',4,'PRESIDENCIAL',1200,NULL),(2,'Quarto Presidencial',4,'PRESIDENCIAL',1200,NULL),(3,'Quarto Presidencial',4,'PRESIDENCIAL',1200,NULL),(4,'Quarto Presidencial',4,'PRESIDENCIAL',1200,NULL),(5,'Quarto Presidencial',4,'PRESIDENCIAL',1200,NULL),(6,'Quarto Luxo Simples',3,'LUXO_SIMPLES',520,NULL),(7,'Quarto Luxo Simples',3,'LUXO_SIMPLES',520,NULL),(8,'Quarto Luxo Simples',3,'LUXO_SIMPLES',520,NULL),(9,'Quarto Luxo Simples',3,'LUXO_SIMPLES',520,NULL),(10,'Quarto Luxo Simples',3,'LUXO_SIMPLES',520,NULL),(11,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(12,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(13,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(14,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(15,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(16,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(17,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(18,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(19,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(20,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(21,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(22,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(23,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(24,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(25,'Quarto Luxo Duplo',3,'LUXO_DUPLO',570,NULL),(26,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(27,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(28,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(29,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(30,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(31,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(32,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(33,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(34,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(35,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(36,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(37,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(38,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(39,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(40,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(41,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(42,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(43,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(44,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(45,'Quarto Luxo Triplo',3,'LUXO_TRIPLO',620,NULL),(46,'Quarto Executivo Simples',3,'EXECUTIVO_SIMPLES',360,NULL),(47,'Quarto Executivo Simples',3,'EXECUTIVO_SIMPLES',360,NULL),(48,'Quarto Executivo Simples',3,'EXECUTIVO_SIMPLES',360,NULL),(49,'Quarto Executivo Simples',3,'EXECUTIVO_SIMPLES',360,NULL),(50,'Quarto Executivo Simples',3,'EXECUTIVO_SIMPLES',360,NULL),(51,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(52,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(53,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(54,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(55,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(56,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(57,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(58,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(59,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(60,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(61,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(62,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(63,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(64,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(65,'Quarto Executivo Duplo',3,'EXECUTIVO_DUPLO',385,NULL),(66,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(67,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(68,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(69,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(70,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(71,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(72,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(73,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(74,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(75,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(76,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(77,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(78,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(79,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(80,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(81,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(82,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(83,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(84,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL),(85,'Quarto Executivo Triplo',3,'EXECUTIVO_TRIPLO',440,NULL);
/*!40000 ALTER TABLE `quartos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-24 12:42:44
